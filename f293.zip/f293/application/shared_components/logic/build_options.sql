prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 293
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>83510709431369223
,p_default_application_id=>293
,p_default_id_offset=>0
,p_default_owner=>'WKSP_TRAININGAPEX'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1580771505366489736)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>49902206714990
);
wwv_flow_imp.component_end;
end;
/
