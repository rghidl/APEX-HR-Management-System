prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 293
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>83510709431369223
,p_default_application_id=>293
,p_default_id_offset=>0
,p_default_owner=>'WKSP_TRAININGAPEX'
);
null;
wwv_flow_imp.component_end;
end;
/
