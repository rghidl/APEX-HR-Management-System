prompt --application/shared_components/user_interface/lovs/r_team_team_code
begin
--   Manifest
--     R_TEAM.TEAM_CODE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>83510709431369223
,p_default_application_id=>293
,p_default_id_offset=>0
,p_default_owner=>'WKSP_TRAININGAPEX'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1580967020611725428)
,p_lov_name=>'R_TEAM.TEAM_CODE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'R_TEAM'
,p_return_column_name=>'ID'
,p_display_column_name=>'TEAM_CODE'
,p_default_sort_column_name=>'TEAM_CODE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>49902501647132
);
wwv_flow_imp.component_end;
end;
/
