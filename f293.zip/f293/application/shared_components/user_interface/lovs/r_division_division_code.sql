prompt --application/shared_components/user_interface/lovs/r_division_division_code
begin
--   Manifest
--     R_DIVISION.DIVISION_CODE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>83510709431369223
,p_default_application_id=>293
,p_default_id_offset=>0
,p_default_owner=>'WKSP_TRAININGAPEX'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1580896202196667735)
,p_lov_name=>'R_DIVISION.DIVISION_CODE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'R_DIVISION'
,p_return_column_name=>'ID'
,p_display_column_name=>'DIVISION_CODE'
,p_default_sort_column_name=>'DIVISION_CODE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>49902401943204
);
wwv_flow_imp.component_end;
end;
/
